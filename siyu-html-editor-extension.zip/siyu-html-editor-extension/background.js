chrome.action.onClicked.addListener(function(tab){
  if(!tab || !tab.id){ return; }
  chrome.tabs.sendMessage(tab.id, {type:'SWEP_TOGGLE'}, function(resp){
    if(chrome.runtime.lastError){
      console.log('[HTML编辑器] toggle failed:', chrome.runtime.lastError.message);
    }
  });
});
