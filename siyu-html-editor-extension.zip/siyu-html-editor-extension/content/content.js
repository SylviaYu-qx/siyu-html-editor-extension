/* ================================================================
   HTML 页面编辑器 · Content Script
   所见即所得 HTML 元素编辑，编辑面板核心由 siyu-ppt-skill
   模板中的"侧边编辑栏"移植而来。
   - 任意 HTML 页面均可激活；Swiss 幻灯片（#deck + .slide）功能完整保留
   - 面板元素 ID 保持 editorPanel / editorToggle，使模板翻页 JS 中
     对 #editorPanel.open 的键盘/滚轮拦截自动生效
   - 通过注入桥接脚本访问页面内部函数 __playSlide / __rescanAsciiCanvases
   - 导出 HTML 时清理所有注入的 UI，样式走扩展 CSS 不残留
   ================================================================ */
(function(){
  'use strict';

  // 注入标记：控制台可见即说明新代码已生效（排查用）
  console.log('[HTML编辑器] v1.1.1 已注入 · 任意页面可编辑 · 面板打开时锁定页面滚动/键盘');

  // ── 任意 HTML 页面均生效（含 Swiss deck 幻灯片）──
  var deck = document.getElementById('deck');
  var slideEls = [].slice.call(document.querySelectorAll('.slide'));
  var hasSlides = slideEls.length > 0;
  // 普通页面没有 deck 时，以 document 为点击事件容器
  var eventRoot = deck || document;

  // ═══════════════════════════════════════
  // 注入页面级桥接脚本（访问页面内部函数）
  // ═══════════════════════════════════════
  function injectBridge(){
    var s = document.createElement('script');
    s.setAttribute('data-swep-bridge', 'true');
    // 使用扩展自己的 URL 加载外部脚本，避免被页面 CSP 拦截内联脚本
    s.src = chrome.runtime.getURL('content/bridge.js');
    (document.head || document.documentElement).appendChild(s);
    // bridge.js 执行完毕后会自行移除
  }
  injectBridge();

  function bridgeCall(op, index){
    document.dispatchEvent(new CustomEvent('swep:call', {
      detail: op === 'sync' ? {op:'sync'} : {op:op, index:index}
    }));
  }
  function currentSlideIndex(){
    bridgeCall('sync');
    return parseInt(document.documentElement.getAttribute('data-swep-current') || '0', 10) || 0;
  }

  // ═══════════════════════════════════════
  // 构建面板 DOM（复刻模板结构）
  // ═══════════════════════════════════════
  function buildPanel(){
    var wrap = document.createElement('div');
    wrap.innerHTML =
      '<button class="editor-toggle" id="editorToggle" title="编辑面板 (E)">&#9881;</button>' +
      '<div class="editor-panel" id="editorPanel">' +
        '<div class="ep-header">' +
          '<span class="ep-title">&#9776;&nbsp; 编辑面板（可拖动）</span>' +
          '<button class="ep-close" id="editorClose">&times;</button>' +
          '<span style="position:absolute;left:20px;bottom:4px;font-size:10px;color:#888;font-weight:400;pointer-events:none;letter-spacing:0">双击标题栏可回原位</span>' +
        '</div>' +
        '<div class="ep-section"><h3>主题色</h3><div class="ep-theme-grid" id="themeGrid"></div>' +
          '<div class="ep-custom-theme" id="epCustomTheme">' +
            '<span class="ep-custom-label">自定义</span>' +
            '<input type="color" id="epCustomColor" value="#AB0022" title="点击选择任意颜色">' +
            '<input type="text" id="epCustomHex" value="#AB0022" maxlength="7" spellcheck="false" placeholder="#RRGGBB">' +
          '</div></div>' +
        '<div class="ep-section" id="elementEditor" style="display:none">' +
          '<h3>元素编辑 <span style="color:#666;font-weight:400;text-transform:none">· 点击页面元素选中</span></h3>' +
          '<div class="ep-control-row"><label>文字</label></div>' +
          '<textarea id="epText" rows="2" style="width:100%;padding:6px 8px;border:1px solid #444;border-radius:4px;background:#222;color:#ccc;font-size:12px;resize:vertical;font-family:inherit"></textarea>' +
          '<div class="ep-control-row" style="margin-top:10px"><label>对齐</label>' +
            '<select id="epAlign"><option value="">继承</option><option value="left">左对齐</option><option value="center">居中</option><option value="right">右对齐</option></select>' +
          '</div>' +
          '<div class="ep-control-row" style="margin-top:10px"><label>字号</label>' +
            '<input type="range" id="epFontSize" min="8" max="120" value="16"><span class="ep-val" id="epFontSizeVal">16px</span>' +
          '</div>' +
          '<div class="ep-control-row"><label>字重</label>' +
            '<select id="epFontWeight"><option value="">继承</option><option value="200">200 ExtraLight</option><option value="300">300 Light</option><option value="400">400 Regular</option><option value="500">500 Medium</option><option value="600">600 SemiBold</option><option value="700">700 Bold</option><option value="800">800 ExtraBold</option></select>' +
          '</div>' +
          '<div class="ep-control-row"><label>颜色</label>' +
            '<input type="color" id="epColor" value="#0a0a0a">' +
            '<input type="text" id="epColorHex" value="#0a0a0a" style="width:64px;padding:2px 6px;border:1px solid #444;border-radius:3px;background:#222;color:#ccc;font-size:11px;text-align:center">' +
          '</div>' +
          '<div class="ep-control-row"><label>行高</label>' +
            '<input type="range" id="epLineHeight" min="0.8" max="2.5" step="0.05" value="1.4"><span class="ep-val" id="epLineHeightVal">1.4</span>' +
          '</div>' +
          '<div class="ep-control-row"><label>间距</label>' +
            '<input type="range" id="epLetterSpacing" min="-0.06" max="0.3" step="0.005" value="0"><span class="ep-val" id="epLetterSpacingVal">0</span>' +
          '</div>' +
          '<div class="ep-btn-row" style="margin-top:12px">' +
            '<button class="ep-btn" id="epInsertText" title="在选中元素后插入一行新文本（继承当前样式）">+ 插入新文本行</button>' +
          '</div>' +
          '<h3 style="margin-top:16px">模块位置微调</h3>' +
          '<div class="ep-btn-row"><button class="ep-btn" data-pos="marginTopUp" title="上移">&#9650; 上</button><button class="ep-btn" data-pos="marginTopDown" title="下移">&#9660; 下</button></div>' +
          '<div class="ep-btn-row"><button class="ep-btn" data-pos="marginLeftUp" title="左移">&#9664; 左</button><button class="ep-btn" data-pos="marginLeftDown" title="右移">&#9654; 右</button></div>' +
          '<div class="ep-btn-row" style="margin-top:10px">' +
            '<button class="ep-btn danger" id="epResetEl">重置元素</button>' +
            '<button class="ep-btn" id="epDeselect">取消选中</button>' +
          '</div>' +
          '<div class="ep-tip">点击页面任意文字元素选中编辑。<br>修改实时生效，刷新后失效（按 <span class="ep-kbd">Ctrl+S</span> 导出 HTML）。</div>' +
        '</div>' +
        '<div class="ep-section">' +
          '<h3>全局操作</h3>' +
          '<div class="ep-btn-row"><button class="ep-btn danger" id="epResetPage">重置此页面修改</button></div>' +
          '<div class="ep-btn-row"><button class="ep-btn" id="epExport">导出 HTML</button><button class="ep-btn danger" id="epResetAll">重置所有修改</button></div>' +
          '<div class="ep-tip">导出会下载修改后的完整 HTML 文件。<br>快捷键：<span class="ep-kbd">E</span> 开关面板 · <span class="ep-kbd">Esc</span> 取消选中 · <b>拖动标题栏</b>移动面板 · 双击标题栏归位</div>' +
        '</div>' +
      '</div>';
    while(wrap.firstChild) document.body.appendChild(wrap.firstChild);
  }
  // 在注入编辑器面板之前捕获 body 快照（普通页面"重置此页面修改"用，须早于 buildPanel）
  var bodySnapshot = document.body.innerHTML;
  buildPanel();

  // ── 主题色预设 ──
  var THEMES = [
    {name:'克莱因蓝 IKB', color:'#002FA7', accent_on:'#ffffff', accent_rgb:'0,47,167', accent_bright:'#5B7BFF', desc:'AI/科技/设计'},
    {name:'柠檬黄', color:'#E8C500', accent_on:'#0a0a0a', accent_rgb:'232,197,0', accent_bright:'#FFE033', desc:'创意/教育/轻量'},
    {name:'柠檬绿', color:'#2ECC40', accent_on:'#0a0a0a', accent_rgb:'46,204,64', accent_bright:'#54FF6B', desc:'增长/可持续/健康'},
    {name:'活力橙', color:'#FF5A1F', accent_on:'#ffffff', accent_rgb:'255,90,31', accent_bright:'#FF8C5A', desc:'安全/警告/行动'},
    {name:'高端红', color:'#AB0022', accent_on:'#0a0a0a', accent_rgb:'171,0,34', accent_bright:'#E8425A', desc:'品牌/公司/总结'},
  ];

  // ── 状态 ──
  var selectedEl = null;
  var originalStyles = null;
  var panel = document.getElementById('editorPanel');
  var toggleBtn = document.getElementById('editorToggle');
  var elementEditor = document.getElementById('elementEditor');

  // ── 齿轮按钮 5 秒后自动收起到屏幕右边缘 ──
  var autoHideTimer = null;
  function scheduleAutoHide(){
    if(autoHideTimer) clearTimeout(autoHideTimer);
    if(panel.classList.contains('open')) return; // 面板打开时不收起
    autoHideTimer = setTimeout(function(){
      toggleBtn.classList.add('auto-hidden');
    }, 5000);
  }
  function cancelAutoHide(){
    if(autoHideTimer){ clearTimeout(autoHideTimer); autoHideTimer = null; }
    toggleBtn.classList.remove('auto-hidden');
  }

  // 记录每页原始 innerHTML 快照（用于"重置此页面修改"，须在任何编辑前捕获）
  var slideSnapshots = hasSlides ? slideEls.map(function(s){ return s.innerHTML; }) : [];

  // ── 面板开关 ──
  // 面板打开时给 <html> 加 .ep-lock（overflow:hidden），从根上钉死页面滚动
  function setPageLock(lock){
    if(lock) document.documentElement.classList.add('ep-lock');
    else document.documentElement.classList.remove('ep-lock');
  }
  function openPanel(){
    panel.classList.add('open');
    setPageLock(true);
    cancelAutoHide();
    toggleBtn.classList.add('hidden');
    if(panel._pinnedLeft !== undefined){
      panel.style.right = 'auto';
      panel.style.left = panel._pinnedLeft+'px';
      panel.style.top = (panel._pinnedTop||0)+'px';
      panel.classList.add('pinned');
    }
  }
  function closePanel(){
    panel.classList.remove('open'); deselectElement();
    setPageLock(false);
    panel.classList.remove('pinned');
    panel.style.left = '';
    panel.style.top = '';
    panel.style.right = '';
    toggleBtn.classList.remove('hidden');
    scheduleAutoHide();
  }
  function togglePanel(){ panel.classList.contains('open') ? closePanel() : openPanel(); }

  // ── 鼠标拖拽面板 ──
  var isDragging = false, dragStartX, dragStartY, panelStartLeft, panelStartTop;
  var HEADER = panel.querySelector('.ep-header');

  HEADER.addEventListener('mousedown', function(e){
    if(e.target.closest('.ep-close')) return;
    isDragging = true;
    dragStartX = e.clientX;
    dragStartY = e.clientY;
    var rect = panel.getBoundingClientRect();
    panelStartLeft = rect.left;
    panelStartTop = rect.top;
    panel.classList.add('dragging');
    if(!panel.classList.contains('pinned')){
      panel.style.right = 'auto';
      panel.style.left = panelStartLeft+'px';
      panel.style.top = panelStartTop+'px';
      panel.classList.add('pinned');
    }
  });

  document.addEventListener('mousemove', function(e){
    if(!isDragging) return;
    e.preventDefault();
    var dx = e.clientX - dragStartX;
    var dy = e.clientY - dragStartY;
    var newLeft = Math.max(0, Math.min(window.innerWidth - 100, panelStartLeft + dx));
    var newTop = Math.max(0, Math.min(window.innerHeight - 60, panelStartTop + dy));
    panel.style.left = newLeft+'px';
    panel.style.top = newTop+'px';
  });

  document.addEventListener('mouseup', function(){
    if(!isDragging) return;
    isDragging = false;
    panel.classList.remove('dragging');
    panel._pinnedLeft = parseInt(panel.style.left);
    panel._pinnedTop = parseInt(panel.style.top);
  });

  HEADER.addEventListener('dblclick', function(){
    panel.classList.remove('pinned');
    panel.style.left = '';
    panel.style.top = '';
    panel.style.right = '';
    panel._pinnedLeft = undefined;
    panel._pinnedTop = undefined;
  });

  toggleBtn.addEventListener('click', togglePanel);
  document.getElementById('editorClose').addEventListener('click', closePanel);

  // 齿轮按钮：鼠标移近滑出，移开后重新计时收起
  toggleBtn.addEventListener('mouseenter', cancelAutoHide);
  toggleBtn.addEventListener('mouseleave', scheduleAutoHide);
  scheduleAutoHide(); // 页面注入后开始 5 秒计时

  // ── 键盘快捷键 ──
  document.addEventListener('keydown', function(e){
    if(e.key === 'e' && !e.ctrlKey && !e.metaKey && !e.altKey && e.target === document.body){
      e.preventDefault();
      togglePanel();
    }
    if(e.key === 'Escape' && selectedEl){
      deselectElement();
    }
    if((e.key === 's' || e.key === 'S') && (e.ctrlKey || e.metaKey) && !e.altKey){
      e.preventDefault();
      document.getElementById('epExport').click();
    }
  });

  // ═══════════════════════════════════════
  // 面板打开时：锁定页面滚动 + 拦截页面键盘
  // 目标：滚轮/触控板/键盘操作只作用于编辑面板，页面翻页与滚动全部冻结
  // ═══════════════════════════════════════
  // 可输入/可编辑控件（不含 button：按钮空格由"面板内按钮"单独处理，
  // 页面上的按钮在面板打开时必须拦截，否则空格会激活页面按钮触发页面动作）
  var FORM_SEL = 'input, textarea, select, [contenteditable]';
  var isPanelOpen = function(){ return panel.classList.contains('open'); };
  // 焦点在可输入/可编辑控件内
  var isEditableTarget = function(t){
    if(!t || !t.closest) return false;
    return !!t.closest(FORM_SEL);
  };
  // 面板在滚动方向上是否已到边界（dir>0 = 内容向下滚，dir<0 = 内容向上滚）
  // 只在"继续朝边界方向滚"时才返回 true —— 面板本身滚动完全放行，
  // 仅当滚到尽头还想继续时拦截，防止滚动穿透带动页面
  var panelAtEdge = function(dir){
    var st = panel.scrollTop, sh = panel.scrollHeight, ch = panel.clientHeight;
    if(dir > 0) return st + ch >= sh - 1;
    if(dir < 0) return st <= 0;
    return false;
  };
  // 滚动类按键
  var SCROLL_KEYS = ['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','PageUp','PageDown','Home','End',' ','Spacebar'];

  // ═══ 全局冻结：window 捕获阶段拦截（页面任何监听都收不到事件）═══
  // 为什么必须 window + capture：
  //  - 页面可能把自己的监听挂 window/document/元素上（如 PPT 的 wheel 翻页、touch 翻页）
  //  - capture 阶段（window→document→…→target）最先执行，此时 stopPropagation 可切断整个传播链，
  //    页面监听（无论挂哪、捕获还是冒泡）全都收不到，翻页逻辑永远不会触发
  //  - 面板自身滚动/输入是浏览器默认行为，不依赖事件传播，stopPropagation 不影响

  // 鼠标滚轮 / 触控板（macOS 触控板手势在 Chrome 里也是发 wheel 事件）：
  //  - 面板外 → preventDefault（冻结页面滚动）+ stopPropagation（页面 wheel 翻页收不到）
  //  - 面板内 → 放行滚动；仅当"继续朝边界方向滚"时 preventDefault（防穿透）；同时 stopPropagation
  window.addEventListener('wheel', function(e){
    if(!isPanelOpen()) return;
    var inPanel = e.target && panel.contains(e.target);
    if(!inPanel){
      e.preventDefault();
    } else if(panelAtEdge(e.deltaY)){
      e.preventDefault();
    }
    e.stopPropagation();
  }, {passive:false, capture:true});

  // 触摸屏：页面 touch 翻页监听一般在 touchend，触摸滚动是默认行为
  //  - 面板外 → preventDefault + stopPropagation（页面既不能滚也不能翻页）
  //  - 面板内 → 放行滚动（不 preventDefault），但 stopPropagation（页面 touch 监听收不到）
  window.addEventListener('touchstart', function(e){
    if(!isPanelOpen()) return;
    var inPanel = e.target && panel.contains(e.target);
    if(!inPanel) e.preventDefault();
    e.stopPropagation();
  }, {passive:false, capture:true});
  window.addEventListener('touchmove', function(e){
    if(!isPanelOpen()) return;
    var inPanel = e.target && panel.contains(e.target);
    if(!inPanel) e.preventDefault();
    e.stopPropagation();
  }, {passive:false, capture:true});
  window.addEventListener('touchend', function(e){
    if(!isPanelOpen()) return;
    var inPanel = e.target && panel.contains(e.target);
    if(!inPanel) e.preventDefault();
    e.stopPropagation();
  }, {passive:false, capture:true});

  // 键盘：window 捕获阶段拦截（比 document 更早，页面任何监听都收不到）
  //  - 焦点在输入框/可编辑区 → 放行正常输入（含光标方向键）
  //  - 焦点在面板内按钮 → Space 放行（激活按钮）；方向键/PageUp 等手动驱动面板滚动
  //  - 焦点在面板外 → 全部拦截（页面翻页/滚动/快捷键全部失效）
  //  - 扩展自身快捷键（E / Esc / Ctrl+S）优先响应
  window.addEventListener('keydown', function(e){
    if(!isPanelOpen()) return;
    var t = e.target;
    var inPanel = t && panel.contains(t);
    var editable = isEditableTarget(t);
    // 扩展快捷键：焦点不在输入框时，E 才作为开关面板快捷键
    if(e.key === 'e' && !e.ctrlKey && !e.metaKey && !e.altKey && !editable){
      e.preventDefault(); e.stopPropagation(); togglePanel(); return;
    }
    // Escape：面板打开时永远拦截——有选中元素先取消选中，否则关闭面板
    // （绝不落到页面：页面的 Escape 快捷键如 PPT 目录视图/弹窗关闭一律失效）
    if(e.key === 'Escape'){
      e.preventDefault(); e.stopPropagation();
      if(selectedEl) deselectElement();
      else closePanel();
      return;
    }
    if((e.key === 's' || e.key === 'S') && (e.ctrlKey || e.metaKey) && !e.altKey){
      e.preventDefault(); e.stopPropagation();
      document.getElementById('epExport').click(); return;
    }
    if(SCROLL_KEYS.indexOf(e.key) !== -1){
      // 输入框/可编辑区内的滚动键 → 放行（光标移动、空格输入）
      if(editable) return;
      // 面板内按钮上的空格 → 放行（激活按钮）
      if((e.key === ' ' || e.key === 'Spacebar') && inPanel && t.closest && t.closest('button')){
        return;
      }
      // 焦点在面板内（非输入框）→ 手动驱动面板滚动，键盘只作用于面板
      if(inPanel){
        var step = 44, pgh = panel.clientHeight;
        if(e.key === 'ArrowDown') panel.scrollTop += step;
        else if(e.key === 'ArrowUp') panel.scrollTop -= step;
        else if(e.key === 'PageDown' || e.key === ' ' || e.key === 'Spacebar') panel.scrollTop += pgh * 0.8;
        else if(e.key === 'PageUp') panel.scrollTop -= pgh * 0.8;
        else if(e.key === 'Home') panel.scrollTop = 0;
        else if(e.key === 'End') panel.scrollTop = panel.scrollHeight;
        e.preventDefault(); e.stopPropagation(); return;
      }
      // 焦点在页面 → 拦截，页面冻结
      e.preventDefault(); e.stopPropagation(); return;
    }
    // 非滚动键：面板内正常操作，面板外拦截
    if(inPanel || editable) return;
    e.preventDefault(); e.stopPropagation();
  }, true);

  // ═══════════════════════════════════════
  // 主题色切换
  // ═══════════════════════════════════════
  function initThemePicker(){
    var grid = document.getElementById('themeGrid');
    var root = document.documentElement;
    var currentAccent = getComputedStyle(root).getPropertyValue('--accent').trim();

    var customTheme = document.getElementById('epCustomTheme');
    var colorInput = document.getElementById('epCustomColor');
    var hexInput = document.getElementById('epCustomHex');

    var matched = false;
    THEMES.forEach(function(t){
      var btn = document.createElement('button');
      btn.className = 'ep-theme-btn';
      if(currentAccent === t.color){ btn.classList.add('active'); matched = true; }
      btn.innerHTML =
        '<span class="ep-theme-swatch" style="background:'+t.color+'"></span>'+
        '<span class="ep-theme-label">'+t.name+'<small>'+t.desc+'</small></span>';
      btn.addEventListener('click', function(){
        applyTheme(t);
        grid.querySelectorAll('.ep-theme-btn').forEach(function(b){ b.classList.remove('active'); });
        btn.classList.add('active');
        customTheme.classList.remove('active');
      });
      grid.appendChild(btn);
    });

    // 自定义颜色：归一化为 #RRGGBB（支持 #RGB 缩写与无 # 输入）
    function normalizeHex(v){
      v = (v||'').trim().replace(/^#/,'');
      if(v.length === 3) v = v.split('').map(function(c){ return c+c; }).join('');
      if(v.length === 6 && /^[0-9a-fA-F]{6}$/.test(v)) return '#'+v;
      return null;
    }
    // 应用自定义主题；成功返回 true
    function applyCustom(hex){
      var h = normalizeHex(hex);
      if(!h) return false;
      applyTheme(buildCustomTheme(h));
      grid.querySelectorAll('.ep-theme-btn').forEach(function(b){ b.classList.remove('active'); });
      customTheme.classList.add('active');
      return true;
    }

    colorInput.addEventListener('input', function(){
      hexInput.value = this.value.toUpperCase();
      applyCustom(this.value);
    });
    hexInput.addEventListener('input', function(){
      var h = normalizeHex(this.value);
      if(h){
        colorInput.value = h;
        applyCustom(h);
      }
    });
    // 失焦时若输入非法，回显当前生效的自定义色
    hexInput.addEventListener('blur', function(){
      if(!normalizeHex(this.value)){
        this.value = (colorInput.value || currentAccent || '#AB0022').toUpperCase();
      }
    });

    // 页面当前主题色非任一预设时，以自定义模式回显
    if(!matched && normalizeHex(currentAccent)){
      colorInput.value = normalizeHex(currentAccent);
      hexInput.value = normalizeHex(currentAccent).toUpperCase();
      customTheme.classList.add('active');
    }
  }

  // 由任意 hex 构建自定义主题（自动计算前景对比色、RGB 值与亮色变体）
  function hexToRgb(hex){
    var h = (hex||'').replace('#','');
    if(h.length === 3) h = h.split('').map(function(c){ return c+c; }).join('');
    return {
      r: parseInt(h.substr(0,2),16),
      g: parseInt(h.substr(2,2),16),
      b: parseInt(h.substr(4,2),16)
    };
  }
  function contrastText(hex){
    var c = hexToRgb(hex);
    var yiq = (c.r*299 + c.g*587 + c.b*114)/1000;
    return yiq >= 150 ? '#0a0a0a' : '#ffffff';
  }
  function lighten(hex, amt){
    var c = hexToRgb(hex);
    var mix = function(v){ return Math.round(v + (255-v)*amt); };
    return '#'+[mix(c.r),mix(c.g),mix(c.b)].map(function(x){
      var h = x.toString(16);
      return h.length === 1 ? '0'+h : h;
    }).join('');
  }
  function buildCustomTheme(hex){
    var c = hexToRgb(hex);
    return {
      name:'自定义',
      color: hex,
      accent_on: contrastText(hex),
      accent_rgb: c.r+','+c.g+','+c.b,
      accent_bright: lighten(hex, 0.3)
    };
  }

  function applyTheme(t){
    var root = document.documentElement;
    root.style.setProperty('--accent', t.color);
    root.style.setProperty('--accent-on', t.accent_on);
    root.style.setProperty('--accent-rgb', t.accent_rgb);
    root.style.setProperty('--accent-bright', t.accent_bright);
    document.querySelectorAll('[style*="var(--accent)"]').forEach(function(el){
      el.style.cssText = el.style.cssText; // force repaint
    });
  }

  // ═══════════════════════════════════════
  // 元素选择与编辑
  // ═══════════════════════════════════════
  document.getElementById('epAlign').addEventListener('change', function(){
    if(!selectedEl) return;
    selectedEl.style.textAlign = this.value || '';
  });

  var EDITABLE_SELECTOR = [
    'h1','h2','h3','h4','p','li','span','strong','em','a',
    'code','pre','blockquote','div','footer','figcaption','dt','dd','td','th',
    '.lead','.t-meta','.t-cat',
    '.chrome-min .l','.chrome-min .r',
    '[style*="font-size"]',
  ].join(',');

  eventRoot.addEventListener('click', function(e){
    if(!panel.classList.contains('open')) return;
    if(e.target.closest('#editorPanel') || e.target.closest('#editorToggle')) return;

    var el = e.target.closest(EDITABLE_SELECTOR);
    if(!el) return;

    if(el.closest('.brand-logo') || el.tagName === 'CANVAS' || el.tagName === 'IMG' || el.tagName === 'svg') return;

    e.preventDefault();
    e.stopPropagation();
    selectElement(el);
  });

  function selectElement(el){
    deselectElement();
    selectedEl = el;
    el.classList.add('ep-selected');
    elementEditor.style.display = 'block';

    var cs = getComputedStyle(el);
    originalStyles = el.getAttribute('style') || '';

    var _temp = document.createElement('div');
    _temp.innerHTML = el.innerHTML.replace(/<br\s*\/?>/gi, '\n');
    document.getElementById('epText').value = _temp.textContent.trim();

    var fs = parseFloat(cs.fontSize);
    document.getElementById('epFontSize').value = Math.round(fs);
    document.getElementById('epFontSizeVal').textContent = Math.round(fs)+'px';

    var fw = cs.fontWeight;
    var fwSelect = document.getElementById('epFontWeight');
    fwSelect.value = (fw === '200'||fw === '300'||fw === '400'||fw === '500'||fw === '600'||fw === '700'||fw === '800') ? fw : '';

    var clr = rgbToHex(cs.color);
    document.getElementById('epColor').value = clr;
    document.getElementById('epColorHex').value = clr;

    var lh = parseFloat(cs.lineHeight) / fs;
    if(isNaN(lh)) lh = 1.4;
    document.getElementById('epLineHeight').value = Math.round(lh*100)/100;
    document.getElementById('epLineHeightVal').textContent = Math.round(lh*100)/100;

    var ls = parseFloat(cs.letterSpacing);
    if(isNaN(ls)) ls = 0;
    document.getElementById('epLetterSpacing').value = ls;
    document.getElementById('epLetterSpacingVal').textContent = (ls >= 0 ? '+' : '') + (ls * 1000).toFixed(0) + '‰';

    var ta = cs.textAlign;
    var alignSelect = document.getElementById('epAlign');
    alignSelect.value = (ta === 'left' || ta === 'center' || ta === 'right') ? ta : '';
  }

  function deselectElement(){
    if(selectedEl){
      selectedEl.classList.remove('ep-selected');
      selectedEl = null;
    }
    elementEditor.style.display = 'none';
    originalStyles = null;
  }

  // ── 实时修改 ──
  document.getElementById('epText').addEventListener('input', function(){
    if(!selectedEl) return;
    var esc = this.value.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    selectedEl.innerHTML = esc.replace(/\n/g, '<br>');
  });

  document.getElementById('epFontSize').addEventListener('input', function(){
    if(!selectedEl) return;
    var val = this.value;
    document.getElementById('epFontSizeVal').textContent = val+'px';
    selectedEl.style.fontSize = val+'px';
  });

  document.getElementById('epFontWeight').addEventListener('change', function(){
    if(!selectedEl) return;
    selectedEl.style.fontWeight = this.value || '';
  });

  document.getElementById('epColor').addEventListener('input', function(){
    if(!selectedEl) return;
    document.getElementById('epColorHex').value = this.value;
    selectedEl.style.color = this.value;
  });

  document.getElementById('epColorHex').addEventListener('input', function(){
    if(!selectedEl) return;
    var val = this.value;
    if(/^#[0-9a-fA-F]{6}$/.test(val)){
      document.getElementById('epColor').value = val;
      selectedEl.style.color = val;
    }
  });

  document.getElementById('epLineHeight').addEventListener('input', function(){
    if(!selectedEl) return;
    var val = parseFloat(this.value);
    document.getElementById('epLineHeightVal').textContent = val;
    selectedEl.style.lineHeight = val;
  });

  document.getElementById('epLetterSpacing').addEventListener('input', function(){
    if(!selectedEl) return;
    var val = parseFloat(this.value);
    document.getElementById('epLetterSpacingVal').textContent = (val >= 0 ? '+' : '') + (val * 1000).toFixed(0) + '‰';
    selectedEl.style.letterSpacing = val+'em';
  });

  // ── 位置微调按钮 ──
  var POS_STEP = 4;
  elementEditor.addEventListener('click', function(e){
    if(!selectedEl) return;
    var btn = e.target.closest('[data-pos]');
    if(!btn) return;
    var dir = btn.getAttribute('data-pos');
    var cur = parseFloat(selectedEl.style.marginTop) || 0;
    var curL = parseFloat(selectedEl.style.marginLeft) || 0;
    switch(dir){
      case 'marginTopUp': selectedEl.style.marginTop = (cur - POS_STEP)+'px'; break;
      case 'marginTopDown': selectedEl.style.marginTop = (cur + POS_STEP)+'px'; break;
      case 'marginLeftUp': selectedEl.style.marginLeft = (curL - POS_STEP)+'px'; break;
      case 'marginLeftDown': selectedEl.style.marginLeft = (curL + POS_STEP)+'px'; break;
    }
  });

  // 重置元素
  document.getElementById('epResetEl').addEventListener('click', function(){
    if(!selectedEl) return;
    if(originalStyles !== null){
      selectedEl.setAttribute('style', originalStyles);
    }
    var el = selectedEl;
    deselectElement();
    selectElement(el);
  });

  // 取消选中
  document.getElementById('epDeselect').addEventListener('click', deselectElement);

  // ── 插入新文本行（在选中元素后插入，继承样式，自动选中新元素） ──
  document.getElementById('epInsertText').addEventListener('click', function(){
    if(!selectedEl) return;
    var cs = getComputedStyle(selectedEl);
    var newEl = document.createElement('p');
    newEl.textContent = '新文本';
    newEl.style.fontSize = cs.fontSize;
    newEl.style.fontWeight = cs.fontWeight;
    newEl.style.color = cs.color;
    newEl.style.lineHeight = cs.lineHeight;
    newEl.style.letterSpacing = cs.letterSpacing;
    newEl.style.margin = '0.4em 0';
    selectedEl.after(newEl);
    selectElement(newEl);
  });

  // ═══════════════════════════════════════
  // 导出 HTML（剥离注入的 UI）
  // ═══════════════════════════════════════
  document.getElementById('epExport').addEventListener('click', function(){
    if(selectedEl) selectedEl.classList.remove('ep-selected');

    var html = document.documentElement.outerHTML;

    if(selectedEl) selectedEl.classList.add('ep-selected');

    var parser = new DOMParser();
    var doc = parser.parseFromString(html, 'text/html');

    var panelEl = doc.querySelector('#editorPanel');
    var toggleEl = doc.querySelector('#editorToggle');
    var bridgeScript = doc.querySelector('script[data-swep-bridge]');
    if(panelEl) panelEl.remove();
    if(toggleEl) toggleEl.remove();
    if(bridgeScript) bridgeScript.remove();

    var blob = new Blob(['<!DOCTYPE html>\n'+doc.documentElement.outerHTML], {type:'text/html;charset=utf-8'});
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = hasSlides ? 'swiss-deck-edited.html' : 'html-edited.html';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  });

  // 重置所有修改
  document.getElementById('epResetAll').addEventListener('click', function(){
    if(!confirm('确定要重置所有修改？这将恢复原始样式和文字内容。')) return;
    location.reload();
  });

  // 重置此页面修改：幻灯片页面恢复当前 slide；普通页面恢复打开时的 body 内容
  document.getElementById('epResetPage').addEventListener('click', function(){
    if(hasSlides){
      var idx = currentSlideIndex();
      var allSlides = document.querySelectorAll('.slide');
      var cur = allSlides[idx];
      if(!cur){ return; }
      if(!confirm('确定要重置当前页(第 '+(idx+1)+' 页)的所有修改？')) return;
      deselectElement();
      cur.innerHTML = slideSnapshots[idx];
      bridgeCall('rescan');
      bridgeCall('playSlide', idx);
      return;
    }
    // 普通页面：恢复打开时的 body 内容
    if(!confirm('确定要恢复页面初始内容？所有修改将丢失。')) return;
    deselectElement();
    // 先把编辑器自身元素从 body 摘除（元素对象保留，事件监听不丢），恢复后再放回
    var editorEls = [toggleBtn, panel].filter(function(el){ return el && el.parentNode === document.body; });
    editorEls.forEach(function(el){ document.body.removeChild(el); });
    document.body.innerHTML = bodySnapshot;
    editorEls.forEach(function(el){ document.body.appendChild(el); });
    bridgeCall('rescan');
  });

  // ── 工具函数 ──
  function rgbToHex(rgb){
    var m = rgb.match(/[\d.]+/g);
    if(!m || m.length < 3) return '#000000';
    return '#'+[m[0],m[1],m[2]].map(function(x){
      var h = parseInt(x).toString(16);
      return h.length === 1 ? '0'+h : h;
    }).join('');
  }

  // ── 初始化 ──
  initThemePicker();

  // 普通页面："重置此页面修改"恢复整个 body 的初始内容，按钮说明同步更新
  if(!hasSlides){
    var resetPageBtn = document.getElementById('epResetPage');
    if(resetPageBtn) resetPageBtn.title = '恢复页面初始内容（撤销本次会话的所有修改）';
  }

  // ═══════════════════════════════════════
  // 与 popup 通信
  // ═══════════════════════════════════════
  if(typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage){
    chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse){
      if(!msg || !msg.type) return;
      if(msg.type === 'SWEP_STATUS'){
        sendResponse({
          supported: true,
          slideCount: document.querySelectorAll('.slide').length,
          panelOpen: panel.classList.contains('open'),
          current: currentSlideIndex() + 1
        });
      } else if(msg.type === 'SWEP_TOGGLE'){
        togglePanel();
        sendResponse({ panelOpen: panel.classList.contains('open') });
      }
    });
  }

})();
