(function(){
  'use strict';
  if(window.__swepBridge) return;
  window.__swepBridge = { ready:true };

  function sync(){
    document.documentElement.setAttribute('data-swep-current', window.__currentSlideIndex || 0);
  }

  sync();

  document.addEventListener('swep:call', function(e){
    var d = e.detail || {};
    if(d.op === 'sync'){ sync(); return; }
    if(d.op === 'playSlide' && window.__playSlide) window.__playSlide(d.index);
    if(d.op === 'rescan' && window.__rescanAsciiCanvases) window.__rescanAsciiCanvases();
  });

  // 执行完移除自身,避免影响导出
  var s = document.currentScript;
  if(s) s.remove();
})();
