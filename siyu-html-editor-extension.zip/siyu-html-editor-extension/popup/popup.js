/* popup.js — 查询当前页支持状态并发送开关命令 */
(function(){
  'use strict';

  var statusEl = document.getElementById('popStatus');
  var toggleBtn = document.getElementById('popToggle');
  var hintEl = document.getElementById('popHint');

  function setStatus(kind, text){
    statusEl.textContent = text;
    statusEl.className = 'pop-status ' + kind;
  }

  function getActiveTab(cb){
    chrome.tabs.query({active:true, currentWindow:true}, function(tabs){
      cb(tabs && tabs[0] ? tabs[0] : null);
    });
  }

  function sendToTab(tab, msg, cb){
    if(!tab || tab.id === undefined){
      cb && cb(null);
      return;
    }
    // file:// 页面可能无法注入，捕获异常
    try {
      chrome.tabs.sendMessage(tab.id, msg, function(resp){
        var err = chrome.runtime.lastError;
        if(err){
          cb && cb(null);
        } else {
          cb && cb(resp);
        }
      });
    } catch(e){
      cb && cb(null);
    }
  }

  getActiveTab(function(tab){
    if(!tab){
      setStatus('warn', '未找到活动标签页');
      return;
    }
    if(!/^https?:|^file:/.test(tab.url || '')){
      setStatus('no', '当前页面类型不支持');
      return;
    }

    sendToTab(tab, {type:'SWEP_STATUS'}, function(resp){
      if(!resp || !resp.supported){
        setStatus('no', '当前页面不支持编辑');
        toggleBtn.disabled = true;
        toggleBtn.textContent = '不支持此页面';
        hintEl.textContent = '仅支持 http/https/file 协议的 HTML 页面';
        return;
      }

      if(resp.slideCount > 0){
        setStatus('ok', '已检测到 ' + resp.slideCount + ' 页 · 当前第 ' + resp.current + ' 页');
      } else {
        setStatus('ok', '支持编辑 · 点击页面元素开始');
      }
      toggleBtn.disabled = false;
      updateToggle(resp.panelOpen);

      toggleBtn.addEventListener('click', function(){
        sendToTab(tab, {type:'SWEP_TOGGLE'}, function(r){
          if(r) updateToggle(r.panelOpen);
        });
      });
    });
  });

  function updateToggle(open){
    toggleBtn.textContent = open ? '关闭编辑面板 (E)' : '打开编辑面板 (E)';
    toggleBtn.classList.toggle('on', !!open);
  }
})();
