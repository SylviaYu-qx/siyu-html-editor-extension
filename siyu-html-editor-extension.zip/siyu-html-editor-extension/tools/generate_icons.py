#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生成 Swiss Deck 编辑面板扩展图标(16/48/128)。
设计:深灰底 + 红色侧栏 + 文本线 —— 瑞士国际主义风。"""
import os
from PIL import Image, ImageDraw

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "icons")

def render(size):
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    s = size / 128.0  # 缩放因子
    def R(v):  # 按 128 基准坐标缩放
        return int(round(v * s))

    # 深灰圆角底
    d.rounded_rectangle([0, 0, size - 1, size - 1], radius=R(20),
                        fill=(20, 20, 20, 255))

    # 左侧红色竖条(瑞士红)
    d.rectangle([R(26), R(24), R(42), R(104)], fill=(171, 0, 34, 255))

    # 右侧三行文本线(浅灰)
    line_y = [R(42), R(62), R(82)]
    line_w = [R(52), R(40), R(46)]
    for y, w in zip(line_y, line_w):
        d.rounded_rectangle([R(58), y, R(58) + w, y + R(8)], radius=R(4),
                            fill=(230, 230, 226, 255))

    # 底部小圆点(accent 高亮)
    d.ellipse([R(96), R(92), R(112), R(108)], fill=(171, 0, 34, 255))

    return img

def main():
    os.makedirs(OUT, exist_ok=True)
    for size in (16, 48, 128):
        render(size).save(os.path.join(OUT, "icon%d.png" % size))
        print("icon%d.png" % size)

if __name__ == "__main__":
    main()
