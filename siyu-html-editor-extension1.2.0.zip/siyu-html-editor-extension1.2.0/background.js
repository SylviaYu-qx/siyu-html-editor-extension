chrome.action.onClicked.addListener(function(tab){
  if(!tab || !tab.id){ return; }
  chrome.tabs.sendMessage(tab.id, {type:'SWEP_TOGGLE'}, function(resp){
    if(chrome.runtime.lastError){
      console.log('[HTML编辑器] toggle failed:', chrome.runtime.lastError.message);
    }
  });
});

// 供 content script 代抓本地图片（file:// 页面直接 fetch 会被 Chrome 拦截）
chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse){
  if(!msg || msg.type !== 'SWEP_FETCH_IMAGE') return;

  fetch(msg.url).then(function(resp){
    if(!resp.ok) throw new Error('HTTP ' + resp.status);
    return resp.blob();
  }).then(function(blob){
    var fr = new FileReader();
    fr.onload = function(){ sendResponse({ok: true, data: fr.result}); };
    fr.onerror = function(){ sendResponse({ok: false}); };
    fr.readAsDataURL(blob);
  }).catch(function(err){
    console.log('[HTML编辑器] 后台抓图失败:', msg.url, err && err.message);
    sendResponse({ok: false});
  });

  return true; // 异步响应
});
